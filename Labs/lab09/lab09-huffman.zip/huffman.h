#ifndef __HUFFMAN_H__
#define __HUFFMAN_H__

#include <string.h>

typedef struct HuffmanNode {
    unsigned char value;
    struct HuffmanNode *left,
                        *right,
                        *parent;
} HuffmanNode, *PHuffmanNode;

typedef PHuffmanNode T;

#include "heap.h"


PHuffmanNode initNode(unsigned char value) {
    return NULL;
}

void computeFreqs(char *text, int freqs[256]) {
}

PHuffmanNode makeTree(int freqs[256]) {
    return NULL;
}

void makeCodes(PHuffmanNode root, char **allCodes) {
}


char *compress(char *textToEncode, char **allCodes) {
    return NULL;
}

char *decompress(char *textToDecode, PHuffmanNode root) {
    return NULL;
}

#endif
