#include "header.h"

void task3(Graph graph) {

}